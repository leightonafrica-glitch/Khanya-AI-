package com.dataspotai.khanya;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
