// Usage: node scripts/set-server-url.js https://your-khanya-server.onrender.com
const fs = require("fs");
const url = (process.argv[2] || process.env.KHANYA_SERVER_URL || "").trim().replace(/\/$/, "");
if (!/^https:\/\/[^\s/]+/.test(url)) { console.error("Give your Khanya AI server address, starting with https://"); process.exit(1); }
const f = "capacitor.config.json";
const c = JSON.parse(fs.readFileSync(f, "utf8"));
c.server.url = url;
fs.writeFileSync(f, JSON.stringify(c, null, 2) + "\n");
console.log("Khanya AI app will open:", url);
