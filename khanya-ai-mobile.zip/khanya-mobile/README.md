# Khanya AI mobile app (Android and iPhone)

This folder turns Khanya AI into a real app that learners can install and test on their phones. The app has its own icon and name and opens full screen. It shows a friendly "You're offline" screen when there's no internet.

The app opens **your hosted Khanya AI server** (the `khanya-ai-server` zip), so accounts, PINs, AI answers and feedback work the same on every phone. **Put the server online first**, following its README, for example on Render. You'll get an address like `https://khanya-ai.onrender.com`.

---

## Option A: test on phones today, with no app build

Once the server is online, testers can install it straight from the browser:

- **Android (Chrome):** open your server address, then tap **⋮ → Install app** (or **Add to Home screen**).
- **iPhone (Safari):** open your server address, then tap **Share → Add to Home Screen**.

It gets its own icon and opens full screen. This is the quickest way to start beta testing.

---

## Option B: Android test app (APK) built for you on GitHub

You don't need any tools on your computer for this.

1. Create a free account at **github.com** and make a new **private** repository.
2. Upload everything in this folder, including the hidden `.github` folder. You can drag and drop the files on GitHub's website.
3. In the repository, go to **Settings → Secrets and variables → Actions → Variables** and click **New repository variable**:
   - Name: `KHANYA_SERVER_URL`
   - Value: your server address, e.g. `https://khanya-ai.onrender.com`
4. Go to **Actions → Build Android test app → Run workflow**.
5. After about 5–10 minutes, open the finished run and download **khanya-ai-apk**. It's a zip containing `app-debug.apk`.
6. Send `app-debug.apk` to your Android testers by WhatsApp, email or Google Drive. On the phone:
   - Tap the file.
   - Allow "Install unknown apps" when asked.
   - Tap **Install**.

This is a **test build**, so Android shows a warning that it's from an unknown source. That's normal for beta testing. For the Google Play Store you'll need a signed release build and a Google Play developer account (a once-off USD 25). The **Internal testing** track on Play is the easiest way to share with up to 100 testers.

### Or build it yourself in Android Studio

1. Install **Android Studio** and **Node.js 18+**.
2. In this folder, run:
   ```
   npm install
   node scripts/set-server-url.js https://your-khanya-server.onrender.com
   npx cap sync android
   npx cap open android
   ```
3. In Android Studio, press **Run ▶** with a phone plugged in (USB debugging on), or use **Build → Build APK(s)**.

---

## Option C: iPhone app (TestFlight)

Apple only allows iPhone apps to be built on a **Mac** with **Xcode**, and testers install them through **TestFlight**. You need an **Apple Developer account** (USD 99 a year).

1. On a Mac, install Xcode and Node.js, then run:
   ```
   npm install
   node scripts/set-server-url.js https://your-khanya-server.onrender.com
   npx cap sync ios
   npx cap open ios
   ```
2. In Xcode, choose your team under **Signing & Capabilities**, then **Product → Archive → Distribute App → TestFlight**.
3. In App Store Connect, add your testers' email addresses. They install the **TestFlight** app and then Khanya AI.

Until then, iPhone testers can use **Option A**.

---

## App details

| | |
|---|---|
| App name | Khanya AI |
| App ID | `com.dataspotai.khanya`. Change it in `capacitor.config.json` before your first store upload if you'd prefer something else. Once it's in a store it can't change. |
| Version | 0.9.0-beta |
| Permissions | Internet, plus camera for taking photos of homework |

If you change the app's look or features, update the **server**. The app shows the latest version automatically, with no reinstall needed.

## Before the app stores

- **Privacy policy:** Google Play and the App Store need a public privacy policy web page. You can link to the Terms page in the app once your real contact details are filled in.
- **Store forms for children's apps:** both stores have extra rules for apps aimed at children. You must fill in the "target audience", "families" or "kids" sections honestly, and the safety settings in the server must stay on.
- **POPIA:** the same points as in the server README.

Created by DataSpot AI.
